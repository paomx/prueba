# -*- coding: utf-8 -*-
{
    'name': 'Pao Portal Consultants',
    'version': '1.0',
    'author': 'samuel castro',
    'category': '',
    'website': 'https://paomx.com',
    'depends': ['portal'
    ],
    'data': [
        # security
        # data
        # demo
        # reports
        # views
        'views/consultants_portal.xml',
        
    ]
}
