from datetime import datetime
import calendar as cal
from dateutil.relativedelta import relativedelta
import pytz
from babel.dates import format_datetime, format_date
import base64
from werkzeug.urls import url_encode

from odoo import http, _, fields
from odoo.http import request
from odoo.tools import html2plaintext, DEFAULT_SERVER_DATETIME_FORMAT as dtf
from odoo.tools.misc import get_lang
from logging import getLogger
from odoo.addons.web.controllers.main import content_disposition
from functools import reduce

_logger = getLogger(__name__)
 
class WebsitePaoConsultants(http.Controller):
    
    @http.route(['/consultants/view'], type='http', auth="user", website=True)
    def calendar_appointment(self, failed=False, **kwargs):
        
        return request.render("pao_website_consultants.pao_consultants", { })
    
