# -*- coding: utf-8 -*-
from . import res_partner
from . import customergroups_group
from . import account_move
from . import sale_report