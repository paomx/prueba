# -*- coding: utf-8 -*-
{
    'name': 'Auditor Agenda',
    'version': '1.0',
    'author': 'samuel castro',
    'category': '',
    'website': 'https://paomx.com',
    'depends': ['portal','auditordaysoff','auditconfirmation','servicereferralagreement'
    ],
    'data': [
        # security
        # data
        # demo
        # reports
        # views
        'views/auditor_agenda_portal.xml',
        
    ]
}
