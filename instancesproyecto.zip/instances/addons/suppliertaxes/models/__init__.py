# -*- coding: utf-8 -*-
from . import purchase_order_line_inherit
from . import purchase_order_inherit
from . import supplier_taxes
from . import res_partner