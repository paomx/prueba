# -*- coding: utf-8 -*-
{
    'name': 'account followup currency',
    'version': '1.0',
    'author': 'samuel castro',
    'category': '',
    'website': 'https://paomx.com',
    'depends': ['base','account','account_reports','account_followup'
    ],
    'data': [
        # security
        #'security/ir.model.access.csv',
        # data
        # demo
        # reports
        # views
        #'views/employee_signature.xml',
    ],
}
