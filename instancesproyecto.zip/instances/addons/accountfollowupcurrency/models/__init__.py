# -*- coding: utf-8 -*-
from . import account_followup_report_inherit