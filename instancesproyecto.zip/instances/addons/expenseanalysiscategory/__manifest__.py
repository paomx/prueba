# -*- coding: utf-8 -*-
{
    'name': 'Expense Analysis Category',
    'version': '1.0',
    'author': 'samuel castro',
    'category': '',
    'website': 'https://paomx.com',
    'depends': ['base','hr_expense'
    ],
    'data': [
        # security
        # data
        # demo
        # reports
        # views
    ],
}
