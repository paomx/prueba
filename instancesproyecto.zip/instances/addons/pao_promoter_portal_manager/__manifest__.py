# -*- coding: utf-8 -*-
{
    'name': 'PAO Promoter Portal Manager',
    'version': '1.0',
    'author': 'samuel castro',
    'category': '',
    'website': 'https://paomx.com',
    'depends': ['portal','sale','website'
    ],
    'data': [
        # security
        'security/ir.model.access.csv',
        # data
        # demo
        # reports
        # views
        'views/promoter_cv.xml',
        'views/promoter_portal_manager.xml',
        
    ]
}
