# -*- coding: utf-8 -*-
{
    'name': 'Edit Sale Order Date',
    'version': '1.0',
    'author': 'samuel castro',
    'category': '',
    'website': 'https://paomx.com',
    'depends': ['base','sale'
    ],
    'data': [
        # security
        'security/groups.xml',
        # data
        # demo
        # reports
        # views
        'views/sale_order_view.xml',
        
    ]
}
