# -*- coding: utf-8 -*-
from . import res_partner
from . import pao_shippers
from . import account_move
from . import sale_report