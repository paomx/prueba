# -*- coding: utf-8 -*-
{
    'name': 'pao audit',
    'version': '1.0',
    'author': 'samuel castro',
    'category': '',
    'website': 'https://paomx.com',
    'depends': ['base','sale'
    ],
    'data': [
        # security
        #'security/groups.xml',
        'security/ir.model.access.csv',
        # data
        # demo
        # reports
        'reports/sale_report.xml',
        # views
        'views/pao_audit.xml',
        'views/sale_order.xml',
    ],
}
