from odoo import fields, models, api

class PaoAudit(models.Model):
    
    _name = 'pao.audit'
    _description = 'audit test'

    name = fields.Char(
        required=True,
        string= "Número",
    )
    customer_id = fields.Many2one(
        string="Cliente",
        comodel_name='res.partner',
        ondelete='restrict',
        required=True,
    )
    @api.model
    def _default_country(self):
        return self.env['res.country'].search(['|',('name','=','Mexico'),('name','=','México')], limit=1)
    country_id = fields.Many2one(
        comodel_name = 'res.country', 
        string='País de Auditoría', 
        help='Select Country', 
        ondelete='restrict',
        default = _default_country
    )  
    state_id = fields.Many2one(
        comodel_name = "res.country.state", 
        string='Estado de Auditoría', 
        help='Select State', 
        ondelete='restrict',
        domain=[('country_id', '=', -1)],
    )
    city_id = fields.Many2one(
        comodel_name = "res.city", 
        string='Ciudad de Auditoría', 
        help='Select City', 
        ondelete='restrict',
        domain=[('state_id', '=', -1)],
    )