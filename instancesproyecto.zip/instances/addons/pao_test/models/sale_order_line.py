from datetime import datetime, timedelta
from odoo import fields, models, api
from logging import Logger, getLogger
import dateutil.parser

_logger = getLogger(__name__)
class SaleOrderLineInherit(models.Model):
    _inherit = 'sale.order.line'
    _description = 'Linea de pedido de venta'

    audit_id = fields.Many2one(
        comodel_name='pao.audit',
        string='Auditoría',
        ondelete='set null',
    )
    