from datetime import datetime, timedelta
from odoo import fields, models, api
from logging import getLogger

_logger = getLogger(__name__)
class SaleOrder(models.Model):

    _inherit='sale.order'
    
    enable_audit_ids = fields.Many2many(
        comodel_name='pao.audit', 
        compute='_get_products', 
        string='Audit',
    )

    @api.depends('partner_id')
    def _get_products(self):
        listaudit = []
        for rec in self:
            domain = [('customer_id', '=', rec.partner_id.id)]
            recaudit = self.env['pao.audit'].search(domain)
            for r in recaudit:
                if r.id not in listaudit:
                    listaudit.append(r.id)
            rec.enable_audit_ids = listaudit
    