from odoo import fields, models, api
from logging import getLogger
from math import acos, cos, sin, radians
import datetime
import calendar
from dateutil.relativedelta import relativedelta
from odoo import exceptions

_logger = getLogger(__name__)

class PurchaseOrderInherit(models.Model):
    _inherit='purchase.order'

    assigned_auditor_id = fields.Integer(
        string = "Reference ID",
        default = 0,
    ) 

    @api.onchange('assigned_auditor_id')
    def onchange_assigned_auditor_id(self):
        for rec in self:
            if rec.assigned_auditor_id and rec.assigned_auditor_id > 0:
                rec.partner_id = rec.assigned_auditor_id

    