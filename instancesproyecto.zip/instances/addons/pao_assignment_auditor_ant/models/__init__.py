# -*- coding: utf-8 -*-
from . import paa_asignment_auditor_scheme
from . import paa_schemes_ranking
from . import res_city_inherit
from . import purchase_order_inherit
from . import res_partner_inherit
from . import product_category_inherit
from . import paa_auditor_assignment_weighting
from . import paa_audit_quantity_month
from . import paa_audit_honorarium_month
from . import paa_configuration_audit_quantity
from . import paa_configuration_audit_honorarium
from . import paa_auditor_qualification