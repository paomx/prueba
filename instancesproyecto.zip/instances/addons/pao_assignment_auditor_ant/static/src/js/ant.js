var FormController = require('web.FormController');
    
    var formController = FormController.include({
        events: {
            'click .myapp-dothis': 'button_clicked',
        },
          button_clicked: function(ev) {
            /*
            this.do_action({
                type: 'ir.actions.act_window', 
                res_model: 'paoassignmentauditor.auditor.qualification', 
                view_mode: 'tree,form', 
                view_type: 'form', 
                views:  [[false, 'list']],
                target: 'new',
            });*/
            ev.preventDefault();
            ev.stopPropagation();
            
            console.log(this);
            alert('Handler for .click() called.')
          },

        _onButtonClicked: function (event) {
            if(event.data.attrs.id === "btn_assignment_auditor"){
                console.log('Test');
                alert('Test');
                /*
                this.do_action({
                    type: 'ir.actions.act_window', 
                    res_model: 'paoassignmentauditor.schemeranking', 
                    view_mode: 'form', 
                    view_type: 'form', 
                    views:  [[false, 'form']],
                    target: 'new',
                });
                */
                /*
                 view_id_tree = self.env['ir.ui.view'].sudo().search([('name','=',"auditor.qualification.tree")])
                    return {
                        'type': 'ir.actions.act_window',
                        'res_model': 'paoassignmentauditor.auditor.qualification',
                        'view_type': 'form',
                        'view_mode': 'tree,form',
                        'views': [(view_id_tree[0].id, 'tree'),(False,'form')],
                        'view_id ref="pao_assignment_auditor.auditor_qualification_tree"': '',
                        'target': 'new',
                        'domain': [],
                    }
                
                */

            }
            this._super(event);
        },
    });










    odoo.define('pao_assignment_auditor.quick_publish_button', function (require) {
        /*'use strict'
    
        var core = require('web.core');
        var utils = require('web.utils');
        var ajax = require('web.ajax');
        var _t = core._t;
        var Widget = require('web.AbstractField');
        var registry = require('web.field_registry');
        console.log("papapa");
        var btn_for_open_popup = Widget.extend({
            events: {
                'click .js_reset_field': 'onClickBtnPopup'
            },
            onClickBtnPopup(ev){
                console.log("entro");
    
            }
        });
        registry.add('btn_popup_assignment_auditor', btn_for_open_popup);
        return btn_for_open_popup;*/
    
        'use strict';     
        var AbstractField = require('web.AbstractField');   
        var core = require('web.core'); 
        var field_registry = require('web.field_registry'); 
        var _t = core._t; 
        console.log("papapa");
        var QuickWebsitePublish = AbstractField.extend({ 
            xmlDependencies: ['/pao_assignment_auditor/static/src/xml/field.xml'],
            template: 'samuel', 
            events: { 
                'click': '_onClick', 
            }, 
            start: function () 
            {
                this.$icon = this.$('.o_button_icon'); 
                return this._super.apply (this, arguments); 
            }, 
            isSet: function () 
            { 
                return true; 
            }, 
            _render : function () 
            { 
                this._super.apply (this, arguments);
                // Displays the Published / Unpublished title 
                var published=this.value; 
                var info=published? _t ("Published"): _t ("Unpublished"); 
                this.$el.attr('aria-label', info).prop ('title', info); 
                this.$icon.toggleClass('text-danger',! published).toggleClass ('text-success', published); 
            }, 
            _onClick: function () 
            { 
                console.log("entro")
                /*var self = this; 
                this._rpc(
                {  
                    model: this.model, 
                    method: 'quick_publish_products',
                    args: [this.res_id], 
                }).then(function (result) 
                { 
                    self.do_action (result);
                }); */
            }, 
        }); 
        field_registry.add('quick_publish_button', QuickWebsitePublish);
        
    });

























    odoo.define('pao_assignment_auditor.widget_one', function (require) {
        'use strict';     
        var AbstractField = require('web.AbstractField');
        var FieldRegistry = require('web.field_registry');
        var core = require('web.core'); 
        var _t = core._t; 
     
        // create an object with any name
        // don't forget to extend to the web.AbstractField object or its child
        var WidgetOne = AbstractField.extend({
            template: 'WidgetOneTemplate', // fill with the template name that will be rendered by odoo mengatur tampilan/view widget
            events: { 
                'click': '_onClick', 
            }, 
            
            start: function () 
            {
                this.$icon = this.$('.o_button_icon'); 
                return this._super.apply(this, arguments); 
                
                
            }, 
            isSet: function () 
            { 
                return true; 
            }, 
            _render : function () 
            { 
                this._super.apply (this, arguments);
                // Displays the Published / Unpublished title 
    
                var published=this.value; 
                var info=published? _t ("Published"): _t ("Unpublished"); 
                this.$el.attr('aria-label', info).prop ('title', info); 
                this.$icon.toggleClass('text-danger',! published).toggleClass('text-success', published); 
            },
            concat_name_parts: function() {
                
                console.log("entrosds");
            },
            _onClick: function () 
            { 
                console.log("entro")
                
                console.log(this.res_id);
                console.log(this.res_partner_ref);
                console.log(this.partner_ref);
                /* 
                var self = this;
                this._rpc(
                {  
                    model: this.model, 
                    method: 'quick_publish_products',
                    args: [this.res_id], 
                }).then(function (result) 
                { 
                    self.do_action (result);
                }); */
            },  
        });
     
        // register the widget to web.field_registry object
        // so we can use our widget in odoo's view/xml file
        // with the code like below
        // <field name="field_one" widget="widget_one" />
        // the 'widget_one' name is up to you, as long as it's always connected/without spaces
        FieldRegistry.add('widget_one', WidgetOne);
     
        // return the widget object
        // so it can be inherited or overridden by another module
        return WidgetOne;
        
        
    });









    odoo.define('pao_assignment_auditor.popup_assignment_auditor', function (require) {
        'use strict';
        
        const widgetRegistry = require('web.widget_registry');
        const Widget = require('web.Widget');
        var FieldManagerMixin = require('web.FieldManagerMixin');
    
        const ToasterButton = Widget.extend({FieldManagerMixin,
            template: 'pao_assignment_auditor.popup_assignment_auditor',
            xmlDependencies: ['/pao_assignment_auditor/static/src/xml/test.xml'],
            events: Object.assign({}, Widget.prototype.events, {
                'click .fa-info-circle': '_onClickButton',
            }),
    
            init: function (parent, data, node) {
                this._super(...arguments);
                FieldManagerMixin.init.call(this);
                this.button_name = node.attrs.button_name;
                this.title = node.attrs.title;
                this.id = data.res_id;
                this.model = data.model;
            },
    
            //--------------------------------------------------------------------------
            // Handlers
            //--------------------------------------------------------------------------
            _onClickButton: function (ev) {
                self = this;
                ev.preventDefault();
                ev.stopPropagation();
                //console.log(FieldManagerMixin);
                console.log(this.getParent())
                /*this._rpc({
                    method: this.button_name,
                    model: this.model,
                    args: [[this.id]],
                }).then(res => {
                    if (res) {
                        this.displayNotification({ message: res.toast_message });
                    }
                })*/
            },
        });
    
        widgetRegistry.add('popup_assignment_auditor', ToasterButton);
    
    
    
    });