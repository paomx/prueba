# -*- coding: utf-8 -*-
from . import res_partner_inherit
from . import purchase_order_inherit
from . import auditor_days_off_days
from . import purchase_order_line