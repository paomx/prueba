# -*- coding: utf-8 -*-
from . import servicereferralagreement_scheme
from . import purchase_order
from . import sale_order
from . import servicereferralagreement_entity
from . import servicereferralagreement_registrynumber
from . import servicereferralagreement_organization
from . import res_partner
from . import servicereferralagreement_auditproducts
from . import sale_order_line
from . import purchase_order_line
from . import product_template
from . import servicereferralagreement_agenda
from . import servicereferralagreement_auditor_exchange_rate
from . import servicereferralagreement_audit_fees
from . import servicereferralagreement_percentage_of_audit_fee