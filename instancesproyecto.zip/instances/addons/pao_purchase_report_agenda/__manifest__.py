# -*- coding: utf-8 -*-
{
    'name': 'pao purchase report agenda',
    'version': '1.0',
    'author': 'samuel castro',
    'category': '',
    'website': 'https://paomx.com',
    'depends': ['base','purchase', 'servicereferralagreement','auditordaysoff','auditconfirmation'
    ],
    'data': [
        # security
        #'security/groups.xml',
        #'security/ir.model.access.csv',
        #'security/groups.xml',
        
        # data
        #'data/mail_data_template.xml',
        # demo
        # reports
        # views
    ],
}
