# -*- coding: utf-8 -*-
from . import purchase_report_inherit