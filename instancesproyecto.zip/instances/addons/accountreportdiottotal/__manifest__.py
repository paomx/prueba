# -*- coding: utf-8 -*-
{
    'name': 'account report diot total',
    'version': '1.0',
    'author': 'samuel castro',
    'category': '',
    'website': 'https://paomx.com',
    'depends': ['base','account','account_reports','l10n_mx_reports'
    ],
    'data': [
        # security
        #'security/ir.model.access.csv',
        # data
        # demo
        # reports
        # views
        #'views/employee_signature.xml',
    ],
}
