# -*- coding: utf-8 -*-
from . import l10n_mx_account_diot_inherit