# -*- coding: utf-8 -*-
{
    'name': 'employee signature',
    'version': '1.0',
    'author': 'samuel castro',
    'category': '',
    'website': 'https://paomx.com',
    'depends': ['base','hr',
    ],
    'data': [
        # security
        'security/ir.model.access.csv',
        # data
        # demo
        # reports
        # views
        'views/employee_signature.xml',
    ],
}
