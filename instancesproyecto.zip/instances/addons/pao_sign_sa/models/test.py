from odoo import api, fields, models
from logging import getLogger

_logger = getLogger(__name__)

class SendSA(models.TransientModel):
    _name = 'send.sa'
    _description = 'send SA'

    sale_order_id = fields.Many2one(
        string="Sale order",
        comodel_name='sale.order',
    )
    subject = fields.Char('Subject', compute=False)
    body = fields.Html('Contents', render_engine='qweb', compute=False, default='', sanitize_style=True)
    
    registration_number_ids = fields.Many2many(
        'servicereferralagreement.registrynumber',
        'servicereferralagreement_registrynumber_test_rel',
        'test_id', 'servicereferralagreement_registrynumber_id',
        string='Registration Numbers',
    )

    destinatario_id = fields.Many2one(
        string = "Destinatario",
        comodel_name ='res.partner',
        domain=[('type', '!=', 'private')]
    )
    
    
    registration_number_ids_filters = fields.Many2many(
        related="sale_order_id.registration_number_order_lines_ids",
    )

  

    def action_send(self):
        _logger.error("entro")
        return {'type': 'ir.actions.act_window_close'}

    