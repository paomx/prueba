# -*- coding: utf-8 -*-
{
    'name': 'Sign Templates',
    'version': '1.0',
    'author': 'samuel castro',
    'category': '',
    'website': 'https://paomx.com',
    'depends': ['base','sign'
    ],
    'data': [
        # security
        # data
        # demo
        # reports
        # views
        'views/sign_send_request.xml',
        'data/cron_data.xml',
        
    ]
}
