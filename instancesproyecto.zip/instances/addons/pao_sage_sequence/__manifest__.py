# -*- coding: utf-8 -*-
{
    'name': 'PAO Sage Sequence',
    'version': '1.0',
    'author': 'samuel castro',
    'category': '',
    'website': 'https://paomx.com',
    'depends': ['base','account'
    ],
    'data': [
        # security
        # data
        'data/ref_sage_sequence.xml',
        # demo
        # reports
        # views
        
    ]
}
