# -*- coding: utf-8 -*-
{
    'name': 'Attachment Download',
    'version': '1.0',
    'author': 'samuel castro',
    'category': '',
    'website': 'https://paomx.com',
    'depends': ['base','account'
    ],
    'data': [
        # security
        # data
        'data/ir_actions_server_data.xml',
        #'views/attachment_views.xml',
        'views/invoice_attachment_view.xml',
        'views/account_move_tree.xml',
        # demo
        # reports
        # views
        
    ]
}
