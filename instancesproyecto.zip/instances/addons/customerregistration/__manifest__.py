# -*- coding: utf-8 -*-
{
    'name': 'Customer Registration',
    'version': '1.0',
    'author': 'samuel castro',
    'category': '',
    'website': 'https://paomx.com',
    'depends': ['base',
    ],
    'data': [
        # security
        # data
        # demo
        # reports
        # views
        'views/res_partner.xml',
    ],
}
