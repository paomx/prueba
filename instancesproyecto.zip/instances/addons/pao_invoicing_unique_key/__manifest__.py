# -*- coding: utf-8 -*-
{
    'name': 'PAO Invoicing Unique Key',
    'version': '1.0',
    'author': 'samuel castro',
    'category': '',
    'website': 'https://paomx.com',
    'depends': ['base','account'
    ],
    'data': [
        # security
        # data
        # demo
        # reports
        # views
        
    ],
}
