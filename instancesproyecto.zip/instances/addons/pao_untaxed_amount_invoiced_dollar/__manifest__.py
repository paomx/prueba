# -*- coding: utf-8 -*-
{
    'name': 'PAO Untaxed Amount Invoiced Dollar',
    'version': '1.0',
    'author': 'samuel castro',
    'category': '',
    'website': 'https://paomx.com',
    'depends': ['base','sale'
    ],
    'data': [
        # security
        # data
        # demo
        # reports
        # views
    ],
}
