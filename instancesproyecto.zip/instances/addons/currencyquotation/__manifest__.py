# -*- coding: utf-8 -*-
{
    'name': 'Currency Quotation',
    'version': '1.0',
    'author': 'samuel castro',
    'category': '',
    'website': 'https://paomx.com',
    'depends': ['base','sale'
    ],
    'data': [
        # security
        # data
        # demo
        # reports
        'reports/sale_report_inherit.xml',
        # views
        'views/res_partner.xml',
        'views/sale_order_portal_content.xml',
        #'views/account_move_view_search.xml',
    ],
}
